Yeah.... I had some major issues with using downloaded font files and linking to Google fonts. I was also confused about what input focus even does.

Otherwise, it was fine. The long list of requirements was a little tedious, but it was helpful to make sure that I didn't forget anything.
